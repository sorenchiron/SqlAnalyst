## by sorenchen
## 2015 10

import os
import glob
import re
import sys


class LogWriter:
    DefaultWriter = sys.stdout
    Verbose = True

    def __init__(self):
        self.Verbose = True
        self.DefaultWriter = sys.stdout

    def set_log_verbose(self, isverbose):
        self.Verbose = isverbose

    def set_log_writer(self, writer):
        self.DefaultWriter = writer

    def close(self):
        if self.DefaultWriter is sys.stdout:
            self._log("WARNING", "Not allow to close std out")
        else:
            self.DefaultWriter.close()

    def _log(self, flag, *content, force=False):
        if self.Verbose or (flag.lower() == "error") or force:
            self.DefaultWriter.write("##" + flag.upper() + "##:" + " ".join(content) + os.linesep)


class SqlEntity(LogWriter):
    def __init__(self, filename, creates, deps):
        super(SqlEntity, self).__init__()
        self.FileName = filename
        self.Creates = creates  # I create these tables
        self.Deps = deps  # I need them to be done first
        self.DepFileEntities = []  # I need these tables
        self.SubRoutineEntities = []  # they need me
        self.InternalDeps = []  # for my own usage
        self.MissingDeps = []  # nobody creates that , I myself didn't create it neither !
        self.IntactDepTables = []
    def __bound_relation__(self, entity_list):
        dep_tables = [db_table[1] for db_table in self.Deps]
        for entity in entity_list:
            if self is entity:
                continue
            self._log("LOG", "Comparing:", self.FileName, 'with', entity.FileName)  ########################LOG
            should_depend = False
            should_gen = False
            if entity not in self.DepFileEntities:  ## do i depend on it?
                for c in entity.Creates:
                    if c in dep_tables:
                        should_depend = True
                        self._log("log", self.FileName, "requires", entity.FileName, "to provide table:", c)
                        if c in self.IntactDepTables:
                            self._log("error", "Duplicate Table", c, "created by", entity.FileName)
                        else:
                            self.IntactDepTables.append(c)
            if entity not in self.SubRoutineEntities:  ## is it my son ?
                for d in entity.Deps:
                    if d[1] in self.Creates:
                        should_gen = True
                        entity.IntactDepTables.append(d[1])  ## my son's table has a source from me
                        self._log("log", self.FileName, "is a father of", entity.FileName, "by providing table:", d[1])
            if should_gen and should_depend:
                self._log("error", "Loop Depend:", self.FileName, entity.FileName)
            if should_depend:  ## i depend on it
                self.DepFileEntities.append(entity)
                entity.SubRoutineEntities.append(self)
            if should_gen:  ## it's my son
                self.SubRoutineEntities.append(entity)
                entity.DepFileEntities.append(self)
        self.InternalDeps = [d[1] for d in self.Deps if d[1] not in self.IntactDepTables]
        self.MissingDeps = [d for d in self.InternalDeps if d not in self.Creates]
        self.MissingDeps = sorted(self.MissingDeps, key=len, reverse=True)

    def is_final_task(self):
        return len(self.SubRoutineEntities) == 0

    def is_base_task(self):
        return len(self.DepFileEntities) == 0
        ##len(self.InternalDeps)

    def is_obsolete_task(self):
        return self.is_base_task() and self.is_final_task()

    def type(self):
        if self.is_obsolete_task():
            print("Obsolete")
        elif self.is_final_task():
            print("Final")
        elif self.is_base_task():
            print("Base")
        else:
            print("Mid")

    def show_stack_tree(self):
        upper_stack = [self]
        next_stack = []
        depth = 1
        print("Layer 0 is the final task")
        while len(upper_stack) > 0:
            print("=======Layer%d start=======" % depth)
            for entity in upper_stack:
                print(entity.FileName)
                next_stack.extend(entity.DepFileEntities)
            upper_stack = list(set(next_stack))
            next_stack.clear()
            depth = depth + 1
        print("========Leaf Tasks========" % depth)

    def _depthTraverse(self, depth=0):
        prefix = ""
        if depth == 0:
            prefix = '*'
        output = prefix + "\t |" * depth + " " + self.FileName
        print(output)
        for e in self.DepFileEntities:
            e._depthTraverse(depth + 1)

    def find_table(self, table):
        Found = False
        if table in self.Creates:
            print("Table found in", self.FileName)
            Found = True
        for e in self.DepFileEntities:
            Found = Found or e.find_table(table)
        return Found

    def show_list_tree(self):
        self._depthTraverse()

    def show_tree(self):
        self.show_list_tree()

    def show(self):
        print("Filename:", self.FileName)
        print("Creates:", "\n".join(self.Creates))
        print("Uses:", "\n".join([ d[0]+d[1] for d in self.Deps if d[1] not in self.InternalDeps]))
        print("Missing:","\n".join(self.MissingDeps))


###########################
###########################

class SqlAnalyst(LogWriter):
    def __init__(self, encoding="utf-8", ):
        super(SqlAnalyst, self).__init__()
        self.EntityList = []
        self.FileNames = []
        self.encoding = encoding
        self.RootEntities = []
        self.BaseEntities = []
        self.MissingTables = []
        self.DefaultEncoding = encoding

    def run(self, tardir="."):
        for filename in self.__scan__(tardir):
            (c, d) = self.__discoverDep__(filename)
            a = SqlEntity(filename, c, d)
            a.set_log_verbose(self.Verbose)
            self.EntityList.append(a)
        self.__buildForest__()
        self.__calculateRoots__()
        self.__calculateBases__()
        self.__calculateMissing__()
        self._log("Done")

    def show(self):
        print("There are", len(self.RootEntities), "trees")
        print("Each tree's Root is marked by \'*\'")
        for e in self.RootEntities:
            e.show_tree()

    def find(self, table):
        Found = False
        for e in self.RootEntities:
            Found = Found or e.find_table(table)
        if not Found:
            print("Table Not Found")

    def show_roots(self):
        sum = 0
        print("following SQL should be executed At Last")
        for entity in self.RootEntities:
            print('[', sum, ']', entity.FileName)
            sum = sum + 1
        print("Final Tasks:", sum)

    def show_leaves(self):
        sum = 0
        print("following SQL can be executed Firstly safely")
        for entity in self.BaseEntities:
            print('[', sum, ']', entity.FileName)
            sum = sum + 1
        print("Base Tasks:", sum)

    def show_info(self, fname):
        found = False
        for e in self.EntityList:
            if fname == e.FileName:
                e.show()
                found = True
                break
        if not found:
            print ("file not found")

    def show_missing(self):
        for tname in self.MissingTables:
            self._log("missing", tname, force=True)

    def show_by_root_no(self, No):
        if No < 0 or (No + 1) > len(self.RootEntities):
            print("invalid index number")
            return
        self.RootEntities[No].show_tree()

    def show_by_leaf_no(self, leaf_no):
        pass
        # base = self.BaseEntities[leaf_no]
        # TODO::

    def useutf8(self):
        self.encoding = "utf-8"

    def usegbk(self):
        self.encoding = "gb2312"

    def usedefault_encoding(self):
        self.encoding = self.DefaultEncoding

    def assign_encoding(self, encoding):
        self.encoding = encoding

    def get_root_entities(self):
        return self.RootEntities

    def reset(self):
        self.EntityList = []
        self.FileNames = []
        self.RootEntities = []
        self.BaseEntities = []

    def gen_utils(self):
        pass
        ## TODO::

    def gen_drop_all(self):
        ## TODO::
        pass

    def gen_drop_mid(self):
        ## TODO::
        pass

    def __scan__(self, tardir):
        os.chdir(tardir)
        FileNames = []
        for fname in glob.glob("*.sql"):
            FileNames.append(fname)
        for fname in glob.glob("*.SQL"):
            FileNames.append(fname)
        FileNames = list(set(FileNames))
        self.FileNames = FileNames
        return FileNames

    def __discoverDep__(self, filename):
        fstr = None
        try:
            self.useutf8()
            fstr = open(filename, 'r', encoding=self.encoding).read().lower()
        except:
            self.usegbk()
            fstr = open(filename, 'r', encoding=self.encoding).read().lower()
        else:
            pass
        create_pattern2 = """(?:create\s+table\s+)(\w+)"""
        creates = [t for t in re.findall(create_pattern2, fstr)]
        ##       dep_pattern1="""(?:from\s+)(\w+\s*\:\s*\:)?(?:\s*)(\w+)"""
        ##       dep_pattern2="""(?:join\s+)(\w+\s*\:\s*\:)?(?:\s*)(\w+)(?:\s+\w+)?(?:\s+on)"""
        dep_pattern = """(?:(?:from|join)\s+)(\w+\s*\:\s*\:)?(?:\s*)(\w+)"""
        deps = [t for t in re.findall(dep_pattern, fstr)]
        return (creates, deps)

    def __buildForest__(self):
        iters = len(self.EntityList) - 1
        EntityList = self.EntityList.copy()
        for i in range(iters):
            entity = EntityList.pop()
            entity.__bound_relation__(EntityList)

    def __calculateRoots__(self):
        self.RootEntities = [e for e in self.EntityList if e.is_final_task()]
        return self.RootEntities

    def __calculateBases__(self):
        self.BaseEntities = [e for e in self.EntityList if e.is_base_task()]
        return self.BaseEntities

    def __calculateMissing__(self):
        missing_tables = []
        for e in self.EntityList:
            missing_tables.extend(e.MissingDeps)
        self.MissingTables = sorted(list(set(missing_tables)), key=len, reverse=True)


#####################################
#####################################
require_argument = True
no_argument = False
arg_is_set = True
arg_not_set = False
arg_val = None
arg_type_fullname = 1
arg_type_abbr = 2
arg_type_value = -1

is_dry_run=False

default_dir = "."

def __none__(sa,*args):
    print("not implemented")

def __bad_arg__(sa,value):
    print ("bad arguments:",value)
    print ("please use help to see the usage")
    exit(0)

def __arg_f__(sa ,value):
    sa.find(value)

def __arg_v__(sa):
    sa.set_log_verbose(True)

def __arg_t__(sa,value):
    global default_dir
    default_dir=value

def __help__(sa):
    print ("version: enhanced lab")
    exit(0)

def __arg_d__(sa):
    global is_dry_run
    is_dry_run=True

def __run__(sa):
    sa.run(default_dir)
    if not is_dry_run:
        sa.show()

def __arg_m__(sa):
    sa.show_missing()

def __arg_i__(sa, value):
    sa.show_info(value)


__arg_map__ = [
    ["bad arg",None,__bad_arg__,no_argument,arg_not_set,arg_val],
    ["verbose", 'v', __arg_v__, no_argument, arg_not_set,arg_val],
    ["target-dir", 't', __arg_t__, require_argument, arg_not_set,arg_val],
    ["encoding", 'e', __none__, require_argument, arg_not_set,arg_val],  # TODO:: set encoding
    ["help", 'h', __help__, no_argument, arg_not_set,arg_val], # TODO:: show help
    ["dry-run", 'd', __arg_d__, no_argument, arg_not_set,arg_val],  #   don't show[]
## run stage
    ["run",None,__run__,no_argument,arg_is_set,arg_val] , # This is the RUN[] stage
## run over
    ["missing", 'm', __arg_m__, no_argument, arg_not_set,arg_val],  #
    ["info", 'i', __arg_i__, require_argument, arg_not_set,arg_val],  #  show deps and gens of a .sql
    ["find", 'f', __arg_f__, require_argument, arg_not_set,arg_val]   # find create table in sql files
]

__arg_index__ = {"full name":0,"abbreviation":1,"function":2,"have argument":3,"argument set":4,"argument value":5}

def __tell_arg_type__(arg):
    m=re.match("^\-\-(\w+)",arg)
    if m is not None:
        return (arg_type_fullname,m.groups()[0])
    m=re.match("^\-(\w+)",arg)
    if m is not None:
        return (arg_type_abbr,m.groups()[0])
    return (arg_type_value,arg)

def __locate_arg_no__(flag_type,flag,arg_map,arg_index):
    query_name=""
    if flag_type==arg_type_fullname:
        query_name="full name"
    elif flag_type==arg_type_abbr:
        query_name="abbreviation"
    i=0
    for arg_info in arg_map:
        if arg_info[arg_index[query_name]]==flag:
            return i
        i+=1
    return 0

def __resolve_arguments__(args,arg_map,arg_index):
    total=len(args)
    dealing=0
    while dealing <= total-1:
        (arg_type,value) = __tell_arg_type__(args[dealing])
        if arg_type<0 :
            continue
        no = __locate_arg_no__(arg_type,value,arg_map,arg_index)
        if arg_map[no][arg_index["have argument"]]:
            if dealing+1 >= total or __tell_arg_type__(args[dealing+1])[0] > 0 : # if no further args given OR  type is flag or abbr flag
                print("flag",value,"requires one argument, none given")
                exit(0)
            dealing+=1
            arg_map[no][arg_index["argument value"]]=args[dealing]
        arg_map[no][arg_index["argument set"]]=True
        dealing+=1


def __exec__(sa,arg_map,arg_index):
    for arg in arg_map:
        if arg[arg_index["argument set"]]:
            if arg[arg_index["have argument"]]:
                arg[arg_index["function"]](sa,arg[arg_index["argument value"]])
            else:
                arg[arg_index["function"]](sa)



if __name__ == "__main__":
    sa = SqlAnalyst()
    sa.set_log_verbose(False)

    if len(sys.argv) > 1:
        args = sys.argv[1:]
        __resolve_arguments__(args,__arg_map__,__arg_index__)
    __exec__(sa,__arg_map__,__arg_index__)

