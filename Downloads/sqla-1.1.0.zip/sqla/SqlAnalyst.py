## by sorenchen
## 2015 10

import os
import glob
import re
import sys


class LogWriter:
    DefaultWriter=sys.stdout
    def __init__(self):
        self.Verbose = True
        self.DefaultWriter = sys.stdout

    def setLogVerbose(self, isverbose):
        self.Verbose = isverbose

    def setLogWriter(self, writer):
        self.DefaultWriter = writer

    def close(self):
        if self.DefaultWriter is sys.stdout:
            self._log("WARNING","Not allow to close std out")
        else:
            self.DefaultWriter.close()

    def _log(self, flag, *content, force=False):
        if self.Verbose or (flag.lower() == "error") or force:
            self.DefaultWriter.write("##"+flag.upper()+"##:"+" ".join(content)+os.linesep)


class SqlEntity(LogWriter):
    def __init__(self, filename, creates, deps):
        super(SqlEntity, self).__init__()
        self.FileName = filename
        self.Creates = creates  # I create these tables
        self.Deps = deps  # I need them to be done first
        self.DepFileEntities = []  # I need these tables
        self.SubRoutineEntities = []  # they need me
        self.InternalDeps = []  # for my own usage

    def _boundRelation(self, entity_list):
        IntactDepTables = []
        dep_tables = [db_table[1] for db_table in self.Deps]
        for entity in entity_list:
            if self is entity:
                continue
            self._log("LOG","Comparing:", self.FileName, 'with', entity.FileName)  ########################LOG
            should_depend = False
            should_gen = False
            if entity not in self.DepFileEntities:  ## do i depend on it?
                for c in entity.Creates:
                    if c in dep_tables:
                        should_depend = True
                        self._log("log",self.FileName, "requires", entity.FileName, "to provide table:", c)
                        if c in IntactDepTables:
                            self._log("error","Duplicate Table",c , "created by", entity.FileName)
                        else:
                            IntactDepTables.append(c)
            if entity not in self.SubRoutineEntities:  ## is it my son ?
                for d in entity.Deps:
                    if d[1] in self.Creates:
                        should_gen = True
                        self._log("log",self.FileName, "is a father of", entity.FileName, "by providing table:", d[1])
            if should_gen and should_depend:
               self._log("error","Loop Depend:", self.FileName, entity.FileName)
            if should_depend:  ## i depend on it
                self.DepFileEntities.append(entity)
                entity.SubRoutineEntities.append(self)
            if should_gen:  ## it's my son
                self.SubRoutineEntities.append(entity)
                entity.DepFileEntities.append(self)
        self.InternalDeps = [d[1] for d in self.Deps if d[1] not in IntactDepTables]

    def isFinalTask(self):
        return len(self.SubRoutineEntities) == 0

    def isBaseTask(self):
        return len(self.DepFileEntities) == 0
        ##len(self.InternalDeps)

    def isObsoleteTask(self):
        return self.isBaseTask() and self.isFinalTask()

    def taskType(self):
        if self.isObsoleteTask():
            print("Obsolete")
        elif self.isFinalTask():
            print("Final")
        elif self.isBaseTask():
            print("Base")
        else:
            print("Mid")

    def showStackTree(self):
        upper_stack = [self]
        next_stack = []
        depth = 1
        print("Layer 0 is the final task")
        while len(upper_stack) > 0:
            print("=======Layer%d start=======" % (depth))
            for entity in upper_stack:
                print(entity.FileName)
                next_stack.extend(entity.DepFileEntities)
            upper_stack = list(set(next_stack))
            next_stack.clear()
            depth = depth + 1
        print("========Leaf Tasks========" % (depth))

    def _depthTraverse(self,depth=0):
        prefix=""
        if depth==0:
            prefix='*'
        output=prefix+"\t\t|"*depth+" "+self.FileName
        print(output)
        for e in self.DepFileEntities:
            e._depthTraverse(depth+1)

    def showListTree(self):
        self._depthTraverse()

    def showTree(self):
        self.showListTree()

    def show(self):
        print("Filename:",self.FileName)
        print("Creates:",",".join(self.Creates))
        print("Uses:",",".join([ d for d in self.Deps if d not in self.InternalDeps]))


class SqlAnalyst(LogWriter):
    def __init__(self, encoding="utf-8",):
        super(SqlAnalyst, self).__init__()
        self.EntityList = []
        self.FileNames = []
        self.encoding = encoding
        self.RootEntities = []
        self.BaseEntities = []

    def _scan(self, tardir):
        os.chdir(tardir)
        FileNames = []
        for fname in glob.glob("*.sql"):
            FileNames.append(fname)
        for fname in glob.glob("*.SQL"):
            FileNames.append(fname)
        FileNames = list(set(FileNames))
        self.FileNames = FileNames
        return FileNames

    def _discoverDep(self, filename):
        fstr=None
        try:
            fstr = open(filename, 'r', encoding=self.encoding).read().lower()
        except:
            self.usegbk()
            fstr = open(filename, 'r', encoding=self.encoding).read().lower()
        else:
            pass
        create_pattern2 = """(?:create\s+table\s+)(\w+)"""
        creates = [t for t in re.findall(create_pattern2, fstr)]
        ##       dep_pattern1="""(?:from\s+)(\w+\s*\:\s*\:)?(?:\s*)(\w+)"""
        ##       dep_pattern2="""(?:join\s+)(\w+\s*\:\s*\:)?(?:\s*)(\w+)(?:\s+\w+)?(?:\s+on)"""
        dep_pattern = """(?:(?:from|join)\s+)(\w+\s*\:\s*\:)?(?:\s*)(\w+)"""
        deps = [t for t in re.findall(dep_pattern, fstr)]
        return (creates, deps)

    def _buildForest(self):
        iters = len(self.EntityList) - 1
        EntityList = self.EntityList.copy()
        for i in range(iters):
            entity = EntityList.pop()
            entity._boundRelation(EntityList)

    def _calculateRoots(self):
        self.RootEntities = [e for e in self.EntityList if e.isFinalTask()]
        return self.RootEntities

    def _calculateBases(self):
        self.BaseEntities = [e for e in self.EntityList if e.isBaseTask()]
        return self.BaseEntities

    def useutf8(self):
        self.encoding="utf-8"
    def usegbk(self):
        self.encoding="gb2312"
    def assignEncoding(self,encoding):
        self.encoding=encoding

    def getRootEntities(self):
        return self.RootEntities

    def showRoots(self):
        sum = 0
        print("following SQL should be executed At Last")
        for entity in self.RootEntities:
            print('[', sum, ']', entity.FileName)
            sum = sum + 1
        print("Final Tasks:", sum)

    def showLeaves(self):
        sum = 0
        print("following SQL can be executed Firstly safely")
        for entity in self.BaseEntities:
            print('[', sum, ']', entity.FileName)
            sum = sum + 1
        print("Base Tasks:", sum)

    def showTreeByRootNo(self, No):
        if No < 0 or (No + 1) > len(self.RootEntities):
            print("invalid index number")
            return
        self.RootEntities[No].showTree()
    def showTreeFromLeaf(self, LeafNo):
        base = self.BaseEntities[LeafNo]
        # TODO::

    def show(self):
        print ("There are",len(self.RootEntities),"trees")
        print ("Each tree's Root is marked by \'*\'")
        for e in self.RootEntities:
            e.showTree()

    def reset(self):
        self.EntityList = []
        self.FileNames = []
        self.RootEntities = []
        self.BaseEntities = []

    def run(self, tardir):
        for filename in self._scan(tardir):
            (c, d) = self._discoverDep(filename)
            a = SqlEntity(filename, c, d)
            self.EntityList.append(a)
        self._buildForest()
        self._calculateRoots()
        self._calculateBases()
        self._log("Done")

if __name__ == "__main__":
    sa=SqlAnalyst()
    sa.setLogVerbose(False)
    sa.run(".")
    sa.show()