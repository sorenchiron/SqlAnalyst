## by sorenchen
## 2015 10
import os
import shutil

winpath="""C:\\Windows\\System32"""
target="sqla.py"
def has_prev_version(path,target):
    files=[]
    for r,d,f in os.walk(path):
        files=f
        break
    if target in files:
        return True
    else:
        return False

if has_prev_version(winpath,target):
    print("removing old version")
    os.remove(winpath+"\\"+target)

print ("installing")
try:
    shutil.copyfile("SqlAnalyst.py",winpath+"\\"+target)
except:
    print("something wrong, please copy it manually")
else:
    print("install succeeded")
rub=input("press any key to proceed")
